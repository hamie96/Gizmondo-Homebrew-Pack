#include <windows.h>
#include "ecursor.h"

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
  UNREFERENCED_PARAMETER(hPrevInstance);
  UNREFERENCED_PARAMETER(lpCmdLine);

  HANDLE eCursorMutex = CreateMutex(NULL, FALSE, _T("eCursorMutex"));
  if (GetLastError() == ERROR_ALREADY_EXISTS)
  {
    HWND hWndOtherInst = FindWindow(_T("eCursorClass"), NULL);
    if (hWndOtherInst)
    {
      SendMessage(hWndOtherInst, WM_USER, 0, 0);
    }
    CloseHandle(eCursorMutex);
    return (0);
  }
  runCursor(TRUE, TRUE);
  CloseHandle(eCursorMutex);
  return (0);
}