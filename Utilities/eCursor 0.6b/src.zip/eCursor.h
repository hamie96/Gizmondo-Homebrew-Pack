#pragma once

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */

extern void runCursor(BOOL enable, BOOL regQuit);
extern BOOL startCursor(BOOL enable);
extern void stopCursor();
extern void enableCursor(BOOL enable);

#ifdef __cplusplus
}
#endif  /* __cplusplus */
