// eCursor.cpp : Defines the entry point for the application.
//
#include <windows.h>
#include <tchar.h>
#include "eCursor.h"
#include "iniparser.h"

ATOM              eCursorRegisterClass(HINSTANCE hInstance);
HWND              eCursorCreateWnd(HINSTANCE);
LRESULT CALLBACK  eCursorWndProc(HWND, UINT, WPARAM, LPARAM);

#pragma pack(1)
typedef struct tagCurEntry
{
  unsigned char   Width;
  unsigned char   Height;
  unsigned char   ColorCount;
  unsigned char   Reserved;
  unsigned short  XHotSpot;
  unsigned short  YHotSpot;
  unsigned int    SizeInBytes;
  unsigned int    FileOffset;
} CURSOR_ENTRY, *LPCURSOR_ENTRY;


typedef struct tagCursorHeaderStruct
{
  unsigned short  Reserved;
  unsigned short  Type;
  unsigned short  Count;
} CURSOR_HEADER_STRUCT, *LPCURSOR_HEADER_STRUCT;

typedef struct tagFakeBitmapInfo
{
  BITMAPINFOHEADER hdr;
  RGBQUAD          colours[256];
} FAKE_BITMAPINFO, *LPFAKE_BITMAPINFO;

#pragma pack()

// Built in cursor definitions
CURSOR_ENTRY      g_curEntry = {32, 32, 0, 0, 16, 16, 304, 22};
unsigned char     g_transparency[128];
FAKE_BITMAPINFO   g_bitmapInfo = {{40, 32, 64, 1, 1, 0, 256, 0, 0, 0, 0}, {{0x00, 0x00, 0x00, 0x00}, {0xFF, 0xFF, 0xFF, 0x00}}};

HDC               g_hdcCompat = NULL;
HBITMAP           g_hBmp      = NULL;
HBITMAP           g_hOldBmp   = NULL;
HPALETTE          g_hPal      = NULL;
HPALETTE          g_hPalOld   = NULL;
LPVOID            g_pvBits    = NULL;
BOOL              g_bEnabled  = TRUE;
BOOL              g_bCanQuit  = TRUE;

int               CURSOR_SPEED_SLOW = 4;
int               CURSOR_SPEED_FAST = 8;

int               QUIT_KEY = VK_ESCAPE;
int               QUIT_KEY_MODIFIERS = MOD_CONTROL | MOD_SHIFT;
int               DISABLE_KEY = VK_TAB;
int               DISABLE_KEY_MODIFIERS = MOD_CONTROL | MOD_SHIFT;
int               cursorX = 0, cursorY = 0;
HRGN              rgnCursor = NULL;
BOOL              hardQuit = FALSE;
HANDLE            g_hThread = NULL;
DWORD             g_dwThreadID = 0;
HWND              g_hWnd;

// defs for eCursorWin project
#ifndef MOD_KEYUP
  #define MOD_KEYUP 4
#endif

#ifndef WS_EX_NOACTIVATE
  #define WS_EX_NOACTIVATE WS_EX_TOPMOST
#endif

#define WM_EXTERNAL_QUIT WM_USER
#define WM_TOGGLE_CURSOR WM_USER + 1

unsigned char defCursor[] = {
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x03, 0xC0, 0x00, 0x00, 0x03, 0xC0, 0x00, 0x00, 0x03, 0xC0, 0x00, 0x00, 0x03, 0xC0, 0x00, 
0x00, 0x03, 0xC0, 0x00, 0x00, 0x03, 0xC0, 0x00, 0x00, 0x03, 0xC0, 0x00, 0x00, 0x03, 0xC0, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0F, 0xF0, 0x0F, 0xF0, 0x0F, 0xF0, 0x0F, 0xF0, 
0x0F, 0xF0, 0x0F, 0xF0, 0x0F, 0xF0, 0x0F, 0xF0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x03, 0xC0, 0x00, 0x00, 0x03, 0xC0, 0x00, 0x00, 0x03, 0xC0, 0x00, 0x00, 0x03, 0xC0, 0x00, 
0x00, 0x03, 0xC0, 0x00, 0x00, 0x03, 0xC0, 0x00, 0x00, 0x03, 0xC0, 0x00, 0x00, 0x03, 0xC0, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xF8, 0x1F, 0xFF, 
0xFF, 0xF8, 0x1F, 0xFF, 0xFF, 0xF8, 0x1F, 0xFF, 0xFF, 0xF8, 0x1F, 0xFF, 0xFF, 0xF8, 0x1F, 0xFF, 
0xFF, 0xF8, 0x1F, 0xFF, 0xFF, 0xF8, 0x1F, 0xFF, 0xFF, 0xF8, 0x1F, 0xFF, 0xFF, 0xF8, 0x1F, 0xFF, 
0xFF, 0xF8, 0x1F, 0xFF, 0xE0, 0x07, 0xE0, 0x07, 0xE0, 0x07, 0xE0, 0x07, 0xE0, 0x07, 0xE0, 0x07, 
0xE0, 0x07, 0xE0, 0x07, 0xE0, 0x07, 0xE0, 0x07, 0xE0, 0x07, 0xE0, 0x07, 0xFF, 0xF8, 0x1F, 0xFF, 
0xFF, 0xF8, 0x1F, 0xFF, 0xFF, 0xF8, 0x1F, 0xFF, 0xFF, 0xF8, 0x1F, 0xFF, 0xFF, 0xF8, 0x1F, 0xFF, 
0xFF, 0xF8, 0x1F, 0xFF, 0xFF, 0xF8, 0x1F, 0xFF, 0xFF, 0xF8, 0x1F, 0xFF, 0xFF, 0xF8, 0x1F, 0xFF, 
0xFF, 0xF8, 0x1F, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF
};

extern int ParseKeyNames(char* szKey);

void MakeWindowRgn()
{
  // create a basic zero-size region to start with
  rgnCursor = CreateRectRgn(0, 0, 0, 0);

  // Use the minimum width and height
  int width = g_bitmapInfo.hdr.biWidth;
  int height = g_bitmapInfo.hdr.biHeight;

  // Use RLE (run-length) style because it goes faster.
  // Row start is where the first opaque pixel is found.  Once
  // a transparent pixel is found, a line region is created.
  // Then row_start becomes the next opaque pixel.
  int row_start, x, y;

  // Go through all rows
  for (y=0; y<height; y++)
  {
    // Start looking at the beginning
    row_start = 0;

    // Go through all columns
    for (x=0; x<width; x++)
    {
      // look up the transparency value in the AND map
      // the map is stored in bmp form (bottom up) and each byte is 8 pixels
      // so formula: (height - 1) - y * 4 give us the row and x >> 3 give us the byte column
      unsigned char trans = g_transparency[((31 - y) * 4) + (x >> 3)];
      // to find the actual bit value, we need to shift right 7 pixels for 1st bit, 6 for 2nd etc.
      // so formula: 7 - (x % 8) gives us the position.
      // finally AND with 1 to clear out all other bits
      int t = (trans >> (7 - (x % 8))) & 1;

      // If t == 1 this pixel is transparent
      if (t)
      {
        // If we haven't found an opaque pixel yet, keep searching
        if (row_start == x) row_start ++;
        else
        {
          // We have found the start (row_start) and end (x) of
          // an opaque line.  Add it to the region.
          HRGN rgnAdd;
          rgnAdd = CreateRectRgn (row_start, y, x, y+1);
          CombineRgn(rgnCursor, rgnCursor, rgnAdd, RGN_OR);
          DeleteObject(rgnAdd);
          row_start = x+1;
        }
      }
    }

    // If the last pixel is still opaque, make a region.
    if (row_start != x)
    {
      HRGN rgnAdd;
      rgnAdd = CreateRectRgn (row_start, y, x, y+1);
      CombineRgn (rgnCursor, rgnCursor, rgnAdd, RGN_OR);
    }
  }
}

BOOL LoadCursor()
{
  WIN32_FIND_DATA fd;
  DWORD dwRead;
  TCHAR path[MAX_PATH], cur[MAX_PATH];

  GetModuleFileName(NULL, path, MAX_PATH);
  TCHAR* tmp = wcsrchr(path, _T('\\'));
  if (tmp)
  {
    *(tmp+1) = 0;
  }
  wcscpy(cur, path);
  wcscat(cur, _T("*.cur"));

  HANDLE hFile = INVALID_HANDLE_VALUE, hFind = FindFirstFile(cur, &fd);

  int numColors = 1 << g_bitmapInfo.hdr.biBitCount;

  if (INVALID_HANDLE_VALUE != hFind)
  {
    FindClose(hFind);
    wcscpy(cur, path);
    wcscat(cur, fd.cFileName);
    hFile = CreateFile(cur, GENERIC_READ, 0, 0, OPEN_EXISTING, 0, NULL);
    DWORD dw = GetLastError();
    if (hFile != INVALID_HANDLE_VALUE)
    {
      CURSOR_HEADER_STRUCT chdr;
      CURSOR_ENTRY entry;
      BITMAPINFOHEADER bhdr;

      ReadFile(hFile, &chdr, sizeof(CURSOR_HEADER_STRUCT), &dwRead, NULL);
      if (chdr.Count != 1)
      {
        ::MessageBox(NULL, _T("Multiple cursors in file"), _T("Invalid Cursor"), MB_OK);
        CloseHandle(hFile);
        return (FALSE);
      }
      ReadFile(hFile, &entry, sizeof(g_curEntry), &dwRead, NULL);
      ReadFile(hFile, &bhdr, sizeof(BITMAPINFOHEADER), &dwRead, NULL);
      if (bhdr.biBitCount > 8 || bhdr.biWidth > 32)
      {
        ::MessageBox(NULL, _T("Format must be:\n32x32\n1, 16 or 256 colour(s)"), _T("Invalid Cursor"), MB_OK);
        CloseHandle(hFile);
        return (FALSE);
      }
      memcpy (&g_curEntry, &entry, sizeof(CURSOR_ENTRY));
      memcpy (&g_bitmapInfo.hdr, &bhdr, sizeof(BITMAPINFOHEADER));

      numColors = 1 << g_bitmapInfo.hdr.biBitCount;
      for (int n = 0; n < numColors; n++)
      {
        ReadFile(hFile, &g_bitmapInfo.colours[n], sizeof(RGBQUAD), &dwRead, NULL);
      }
    }
  }

  g_bitmapInfo.hdr.biHeight /= 2;

  HDC hdc = GetDC(NULL);
  g_hdcCompat = CreateCompatibleDC(hdc);
  g_hBmp = CreateDIBSection(g_hdcCompat, (LPBITMAPINFO) &g_bitmapInfo, DIB_RGB_COLORS, &g_pvBits, NULL, 0);
  g_hOldBmp = (HBITMAP)SelectObject(g_hdcCompat, g_hBmp);

  // size number of 32 bit words (rounded up) that a line occupies * the height * 4
  int size = ((((g_bitmapInfo.hdr.biWidth * g_bitmapInfo.hdr.biBitCount) + 0x1F) >> 5) * g_bitmapInfo.hdr.biHeight) << 2;

  if (hFile != INVALID_HANDLE_VALUE)
  {
    ReadFile(hFile, g_pvBits, size, &dwRead, NULL);
    ReadFile(hFile, g_transparency, 128, &dwRead, NULL);
    CloseHandle(hFile);
  }
  else
  {
    memcpy(g_pvBits, defCursor, size);
    memcpy(g_transparency, &defCursor[size], 128);
  }

  ReleaseDC(NULL, hdc);

  LPLOGPALETTE lpLogPal = (LPLOGPALETTE) malloc(sizeof(LOGPALETTE) + numColors * sizeof(PALETTEENTRY));
  lpLogPal->palVersion = 0x0300;
  lpLogPal->palNumEntries = numColors;
  for (int n = 0; n < numColors; n++)
  {
    lpLogPal->palPalEntry[n].peBlue  = g_bitmapInfo.colours[n].rgbBlue;
    lpLogPal->palPalEntry[n].peRed   = g_bitmapInfo.colours[n].rgbRed;
    lpLogPal->palPalEntry[n].peGreen = g_bitmapInfo.colours[n].rgbGreen;
    lpLogPal->palPalEntry[n].peFlags = 0;
  }

  g_hPal = CreatePalette(lpLogPal);
  free(lpLogPal);

  g_hPalOld = (HPALETTE) SelectPalette(g_hdcCompat, g_hPal, FALSE);
  return (TRUE);
}

void UnregisterActionKeys(HWND hWnd)
{
  int id = 0;
  for (int n = VK_LEFT; n <= VK_DOWN; n++)
  {
    UnregisterHotKey(hWnd, id++);
    UnregisterHotKey(hWnd, id++);
    UnregisterHotKey(hWnd, id++);
  }
  UnregisterHotKey(hWnd, id++);
  UnregisterHotKey(hWnd, id++);
  UnregisterHotKey(hWnd, id++);

  UnregisterHotKey(hWnd, id++);
  UnregisterHotKey(hWnd, id++);
  UnregisterHotKey(hWnd, id++);
}

void RegisterActionKeys(HWND hWnd)
{
  int id = 0;
  for (int n = VK_LEFT; n <= VK_DOWN; n++)
  {
    RegisterHotKey(hWnd, id++, 0, n);
    RegisterHotKey(hWnd, id++, MOD_SHIFT, n);
    RegisterHotKey(hWnd, id++, MOD_CONTROL, n);
  }
  RegisterHotKey(hWnd, id++, MOD_KEYUP, VK_RETURN);
  RegisterHotKey(hWnd, id++, MOD_CONTROL|MOD_KEYUP, VK_RETURN);
  RegisterHotKey(hWnd, id++, MOD_SHIFT|MOD_KEYUP, VK_RETURN);
  
  RegisterHotKey(hWnd, id++, MOD_KEYUP, VK_SPACE);
  RegisterHotKey(hWnd, id++, MOD_CONTROL|MOD_KEYUP, VK_SPACE);
  RegisterHotKey(hWnd, id++, MOD_SHIFT|MOD_KEYUP, VK_SPACE);
}

void RegisterMasterKeys(HWND hWnd)
{
  RegisterHotKey(hWnd, 255+DISABLE_KEY, DISABLE_KEY_MODIFIERS, DISABLE_KEY);
  if (g_bCanQuit)
  {
    RegisterHotKey(hWnd, 255+QUIT_KEY, QUIT_KEY_MODIFIERS, QUIT_KEY);
  }
}

void RegisterAllKeys(HWND hWnd)
{
  RegisterMasterKeys(hWnd);
  if (g_bEnabled)
  {
    RegisterActionKeys(hWnd);
  }
}

void FreeCursor(HWND hWnd)
{
  UnregisterHotKey(hWnd, 255+DISABLE_KEY);
  UnregisterHotKey(hWnd, 255+QUIT_KEY);
  UnregisterActionKeys(hWnd);

  SelectObject(g_hdcCompat, g_hOldBmp);
  SelectObject(g_hdcCompat, g_hPalOld);
  DeleteObject(g_hBmp);
  DeleteObject(g_hPal);
  DeleteObject(rgnCursor);
  DeleteDC(g_hdcCompat);
}

int ParseModNames(char* szMod)
{
  int ret = 0;
  if (!szMod)
    return (-1);
  else if (!_stricmp(szMod, "NONE"))
    return (0);
  else
  {
    char* szTmp = strtok(szMod, "|");
    while (szTmp)
    {
      if (!_stricmp(szTmp, "CTRL"))
        ret |= MOD_CONTROL;
      else if (!_stricmp(szTmp, "SHIFT"))
        ret |= MOD_SHIFT;
      szTmp = strtok(NULL, "|");
    }
  }
  return (ret);
}

void runCursor(BOOL enable, BOOL regQuit)
{
  MSG msg;
  HINSTANCE hInstance = GetModuleHandle(NULL);

  g_bEnabled = enable;
  g_bCanQuit = regQuit;

	dictionary*	ini = iniparser_new("eCursor.ini");
	if (ini != NULL)
  {
    int i = iniparser_getint(ini, "CursorSpeed:Slow", -1);
    if (i > 0)
      CURSOR_SPEED_SLOW = i ;
    i = iniparser_getint(ini, "CursorSpeed:Fast", -1);
    if (i > 0)
      CURSOR_SPEED_FAST = i ;

    i = ParseKeyNames(iniparser_getstring(ini, "DisableKey:Key", NULL));
    if (i > 0)
    {
      DISABLE_KEY = i;
    }

    i = ParseModNames(iniparser_getstring(ini, "DisableKey:Mods", NULL));
    if (i >= 0)
    {
      DISABLE_KEY_MODIFIERS = i;
    }

    i = ParseKeyNames(iniparser_getstring(ini, "QuitKey:Key", NULL));
    if (i > 0)
    {
      QUIT_KEY = i;
    }

    i = ParseModNames(iniparser_getstring(ini, "QuitKey:Mods", NULL));
    if (i >= 0)
    {
      QUIT_KEY_MODIFIERS = i;
    }

    iniparser_free(ini);
  }


  cursorX = (GetSystemMetrics(SM_CXSCREEN) >> 1) - g_curEntry.XHotSpot;
  cursorY = (GetSystemMetrics(SM_CYSCREEN) >> 1) - g_curEntry.YHotSpot;

  if (!LoadCursor())
  {
    return;
  }

  MakeWindowRgn();

  eCursorRegisterClass(hInstance);
  while (true)
  {
    if (!(g_hWnd = eCursorCreateWnd(hInstance)))
    {
      UnregisterClass(_T("eCursorClass"), hInstance);
      return;
    }

    if (g_bEnabled)
    {
      SetWindowPos(g_hWnd, HWND_TOP, cursorX, cursorY, 0, 0, SWP_NOSIZE|SWP_SHOWWINDOW|SWP_NOACTIVATE);
    }

    while (GetMessage(&msg, g_hWnd, 0, 0) > 0)
    {
      DispatchMessage(&msg);
    }

    // flush queue
    while (PeekMessage(&msg, g_hWnd, 0, 0, PM_REMOVE)) 
    {
    }

    if (hardQuit)
    {
      break;
    }
    Sleep(0x80);
  }
  FreeCursor(g_hWnd);

  UnregisterClass(_T("eCursorClass"), hInstance);
}


DWORD CursorThreadFunc(DWORD param)
{
  runCursor(param, FALSE);
  return (0);
}


BOOL startCursor(BOOL enable)
{
  g_hThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CursorThreadFunc, (LPVOID)enable, 0, &g_dwThreadID);
  return (NULL != g_hThread);
}

void stopCursor()
{
  if (NULL != g_hThread)
  {
    hardQuit = TRUE;
    PostThreadMessage(g_dwThreadID, WM_QUIT, 0, 0);
    WaitForSingleObject(g_hThread, INFINITE);
  }
}

void enableCursor(BOOL enable)
{
  PostMessage(g_hWnd, WM_TOGGLE_CURSOR, enable, 0);
}

ATOM eCursorRegisterClass(HINSTANCE hInstance)
{
  WNDCLASS wc;

  wc.style      = CS_HREDRAW | CS_VREDRAW;
  wc.lpfnWndProc  = eCursorWndProc;
  wc.cbClsExtra    = 0;
  wc.cbWndExtra    = 0;
  wc.hInstance    = hInstance;
  wc.hIcon        = NULL;
  wc.hCursor      = NULL;
  wc.hbrBackground  = (HBRUSH)(COLOR_WINDOW+1);
  wc.lpszMenuName  = NULL;
  wc.lpszClassName  = _T("eCursorClass");

  return RegisterClass(&wc);
}

HWND GetCorrectOwner(HWND hWnd)
{
  HWND hwndtmp = GetWindow(NULL, GW_CHILD);
  // if this is not us
  if (hwndtmp != hWnd)
  {
    // while the child window is not visible
    while (!IsWindowVisible(hwndtmp))
    {
      // find the next windows
      hwndtmp = GetWindow(hwndtmp, GW_HWNDNEXT);
      // if this is us break;
      if (hwndtmp == hWnd || hwndtmp == NULL)
        break;
    }
  }
  return (hwndtmp);
}

HWND eCursorCreateWnd(HINSTANCE hInstance)
{

  HWND hwndOwner = GetCorrectOwner(FindWindow(_T("HHTaskBar"), NULL));
  HWND hWnd = CreateWindowEx(WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE,_T("eCursorClass"), NULL, WS_POPUP,
    cursorX, cursorY , 32, 32, hwndOwner, NULL, hInstance, NULL);

  return (hWnd);
}

BOOL OwnerCheck(HWND hWnd)
{
  // find the first child of the desktop
  HWND hwndtmp = GetCorrectOwner(hWnd);

  // if the window found is not us
  if (hwndtmp != hWnd)
  {
    // if it is not our owner, we need to destroy and re-create ourselves to
    // be top of the z-order. This _really_ sux...
    if (hwndtmp != GetWindow(hWnd, GW_OWNER))
    {
      return (FALSE);
    }
  }
  return (TRUE);
}

void enable(HWND hWnd)
{
  if (g_bEnabled)
  {
    SetWindowPos(hWnd, HWND_TOPMOST, cursorX, cursorY, 0, 0, SWP_NOSIZE|SWP_NOACTIVATE|SWP_SHOWWINDOW);
    RegisterActionKeys(hWnd);
  }
  else
  {
    SetWindowPos(hWnd, NULL, 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE|SWP_NOACTIVATE|SWP_HIDEWINDOW);
    UnregisterActionKeys(hWnd);
  }
}

LRESULT CALLBACK eCursorWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  PAINTSTRUCT ps;
  HDC hdc;
  static HRGN tmpRGN = NULL;

  switch (message)
  {
    case WM_CREATE:
    {
      tmpRGN = CreateRectRgn(0, 0, 0, 0);
      CombineRgn(tmpRGN, rgnCursor, NULL, RGN_COPY);
      SetWindowRgn(hWnd, tmpRGN, FALSE);
      RegisterAllKeys(hWnd);
      HWND hwndSIP = FindWindow(_T("Sipwndclass"), NULL);
      if ((GetWindow(hWnd, GW_OWNER) == hwndSIP))
      {
        SetWindowPos(hwndSIP, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE);
        //SetWindowPos(hWnd, HWND_TOPMOST, cursorX, cursorY, 0, 0, SWP_NOSIZE|SWP_SHOWWINDOW|SWP_NOACTIVATE);
      } 
      break;
    }
    case WM_DESTROY:
    {
      DeleteObject(tmpRGN);
      if (GetAsyncKeyState(VK_LBUTTON) & 0x8000)
      {
        mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
      }
      PostQuitMessage(0);
      break;
    }
    case WM_PAINT:
    {
      hdc = BeginPaint(hWnd, &ps);
      ::BitBlt( hdc, 0, 0, 32, 32, g_hdcCompat, 0, 0, SRCCOPY );
      EndPaint(hWnd, &ps);
      break;
    }
    case WM_HOTKEY:
    {
      int isMove = 0;
      int scrX = GetSystemMetrics(SM_CXSCREEN);
      int scrY = GetSystemMetrics(SM_CYSCREEN);
      int key  = lParam >> 16;
      if (key >= VK_LEFT && key <= VK_DOWN)
      {
        isMove = 1;
        int speed = lParam & 0x04 ? CURSOR_SPEED_SLOW : CURSOR_SPEED_FAST;
        for (int i = VK_LEFT; i <= VK_DOWN; i++)
        {
          BOOL down = ((GetAsyncKeyState(i) & 0x8000) == 0x8000);
          if (down)
          {
            switch (i)
            {
              case VK_LEFT:
                cursorX -= speed;
              break;
              case VK_RIGHT:
                cursorX += speed;
              break;
              case VK_UP:
                cursorY -= speed;
              break;
              case VK_DOWN:
                cursorY += speed;
              break;
            }
          }
        }
        if (cursorX < -g_curEntry.XHotSpot) cursorX = -g_curEntry.XHotSpot; 
        else if (cursorX > (scrX - g_curEntry.XHotSpot - 1)) cursorX = (scrX - g_curEntry.XHotSpot - 1);

        if (cursorY < -g_curEntry.YHotSpot) cursorY = -g_curEntry.YHotSpot; 
        else if (cursorY > (scrY - g_curEntry.YHotSpot - 1)) cursorY = (scrY - g_curEntry.YHotSpot - 1);
      }
      // calculate mouse position in mickeys
      int dx = ((cursorX + g_curEntry.XHotSpot) * 65535) / scrX;
      int dy = ((cursorY + g_curEntry.YHotSpot) * 65535) / scrY;

      if (isMove)
      {
        if (!OwnerCheck(hWnd))
        {
          DestroyWindow(hWnd);
        }
        else
        {
          SetWindowPos(hWnd, HWND_TOPMOST, cursorX, cursorY, 0, 0, SWP_NOSIZE|SWP_SHOWWINDOW|SWP_NOACTIVATE);
        }

        mouse_event(MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_MOVE, dx, dy, 0, 0);
      }
      else if (key == VK_RETURN || key == VK_SPACE)
      {
        static BOOL buttonDown = FALSE;

        if ((LOWORD(lParam) & MOD_KEYUP) == MOD_KEYUP)
        {
          int flags = MOUSEEVENTF_ABSOLUTE | ((key == VK_RETURN) ? MOUSEEVENTF_LEFTUP : MOUSEEVENTF_RIGHTUP);
          mouse_event(flags, dx, dy, 0, 0);
          SetWindowPos(hWnd, NULL, 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE|SWP_NOACTIVATE|SWP_SHOWWINDOW);
          buttonDown = FALSE;
        }
        else
        {
          if (!buttonDown)
          {
            int flags = MOUSEEVENTF_ABSOLUTE | ((key == VK_RETURN) ? MOUSEEVENTF_LEFTDOWN : MOUSEEVENTF_RIGHTDOWN);
            mouse_event(flags, dx, dy, 0, 0);
            SetWindowPos(hWnd, NULL, 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE|SWP_NOACTIVATE|SWP_HIDEWINDOW);
            buttonDown = TRUE;
          }
        }
      }
      else if (key == DISABLE_KEY)
      {
        g_bEnabled = !g_bEnabled;
        enable(hWnd);
      }
      else if (key == QUIT_KEY)
      {
        hardQuit = TRUE;
        DestroyWindow(hWnd);
      }
      break;
    }
    case WM_TOGGLE_CURSOR:
    {
      g_bEnabled = wParam;
      enable(hWnd);
      break;
    }
    case WM_EXTERNAL_QUIT:
    {
      hardQuit = TRUE;
      DestroyWindow(hWnd);
      break;
    }
    default:
      return DefWindowProc(hWnd, message, wParam, lParam);
  }
  return 0;
}

