#include <windows.h>

typedef struct tagKeyMapEntry
{
  char* szKeyName;
  int   vKey;
} KEYMAP_ENTRY, *LPKEYMAP_ENTRY;


KEYMAP_ENTRY KeyMap[] = {
  {"TAB", VK_TAB},
  {"ESC", VK_ESCAPE},
  {"F1", VK_F1},
  {"F2", VK_F2},
  {"F3", VK_F3},
  {"F4", VK_F4},
  {"F11", VK_F11},
  NULL
};

int ParseKeyNames(char* szKey)
{
  if (!szKey)
    return (-1);

  LPKEYMAP_ENTRY ent = KeyMap;
  while (ent)
  {
    if (!_stricmp(szKey, ent->szKeyName))
      return (ent->vKey);
    ent++;
  }
  return (-1);
}