#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#include "driver.h"
#include "cpuintrf.h"
#include "memory.h"
#include "z80/z80.h"
#include "cz80.h"

cz80_struc mame4all_cz80_struc;

#if CZ80_USE_WORD_HANDLER
static void my_writemem16(unsigned int address, unsigned int data)
{
	cpu_writemem16(address,(unsigned char)data&0xff);
	cpu_writemem16(address+1,((unsigned char)(data>>8))&0xff);
}
static unsigned short my_readmem16(unsigned int address)
{
	return (((cpu_readmem16(address))&0xFF)|((cpu_readmem16(address+1)&0xff)<<8));
}
#endif

static int cpu_cz80_irq_callback(int param)
{
//printf("cpu_z80_irq_callback %i\n",param); fflush(stdout);
	return param;
}

static void cpu_cz80_reti_callback(void)
{
//	puts("cpu_z80_reti_callback"); fflush(stdout);
}

void Z80_Reset(Z80_DaisyChain *daisy_chain)
{
puts("Z80_Reset"); fflush(stdout);
if (daisy_chain)
{
puts(" Caution !!! Z80_DaisyChain not implementated yet !!!");fflush(stdout);
}
	Cz80_Init(&mame4all_cz80_struc);
	Cz80_Set_Fetch(&mame4all_cz80_struc,0x0000,0xFFFF,(unsigned)OP_ROM);
	Cz80_Set_ReadB(&mame4all_cz80_struc,(CZ80_READ *)&cpu_readmem16);
	Cz80_Set_WriteB(&mame4all_cz80_struc,(CZ80_WRITE *)&cpu_writemem16);
#if CZ80_USE_WORD_HANDLER
	Cz80_Set_ReadW(&mame4all_cz80_struc,&my_readmem16);
	Cz80_Set_WriteW(&mame4all_cz80_struc,&my_writemem16);
#endif
	Cz80_Set_INPort(&mame4all_cz80_struc,(CZ80_READ *)&cpu_readport);
	Cz80_Set_OUTPort(&mame4all_cz80_struc,(CZ80_WRITE *)&cpu_writeport);
	Cz80_Set_IRQ_Callback(&mame4all_cz80_struc,cpu_cz80_irq_callback);
	Cz80_Set_RETI_Callback(&mame4all_cz80_struc,cpu_cz80_reti_callback);
	Cz80_Reset(&mame4all_cz80_struc);
}

void Z80_GetRegs(Z80_Regs *Regs)
{
//puts("Z80_GetRegs"); fflush(stdout);
	fast_memcpy(Regs,(void *)&mame4all_cz80_struc,sizeof(cz80_struc));
}

void Z80_SetRegs (Z80_Regs *Regs)
{
//puts("Z80_SetRegs"); fflush(stdout);
	fast_memcpy((void *)&mame4all_cz80_struc,Regs,sizeof(cz80_struc));
}

unsigned Z80_GetPC (void)
{
//printf("Z80_GetPC = %.4X\n",Cz80_Get_PC(&mame4all_cz80_struc)); fflush(stdout);
	return Cz80_Get_PC(&mame4all_cz80_struc);
}

void Z80_Cause_Interrupt(int type)
{
//printf("Z80_Cause_Interrupt %i\n",type); fflush(stdout);
	if (type == Z80_NMI_INT)
		Cz80_Set_NMI(&mame4all_cz80_struc);
	else if (type >= 0)
		Cz80_Set_IRQ(&mame4all_cz80_struc, type & 0xff);
}

void Z80_Clear_Pending_Interrupts(void)
{
//puts("Z80_Clear_Pending_Interrupts"); fflush(stdout);
	Cz80_Clear_IRQ(&mame4all_cz80_struc);
	Cz80_Clear_NMI(&mame4all_cz80_struc);
}

int Z80_Execute(int cycles)
{
/*
//printf("Z80_Execute %i\n",cycles); fflush(stdout);
int faltan=cycles;
while(faltan>0)
{
faltan-=Cz80_Exec(&mame4all_cz80_struc,10);
}
//puts("-"); fflush(stdout);
return cycles-faltan;
*/
	return Cz80_Exec(&mame4all_cz80_struc,cycles);
}

