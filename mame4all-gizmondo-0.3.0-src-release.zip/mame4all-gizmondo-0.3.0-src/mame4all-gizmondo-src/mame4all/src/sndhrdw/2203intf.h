#ifndef FMINTF_H
#define FMINTF_H
#include "sndhrdw/psgintf.h"
#endif
