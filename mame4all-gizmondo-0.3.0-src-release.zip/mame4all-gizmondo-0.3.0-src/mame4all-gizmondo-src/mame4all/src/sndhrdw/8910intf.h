#ifndef AY8910INTF_H
#define AY8910INTF_H
#include "sndhrdw/psgintf.h"
#endif
