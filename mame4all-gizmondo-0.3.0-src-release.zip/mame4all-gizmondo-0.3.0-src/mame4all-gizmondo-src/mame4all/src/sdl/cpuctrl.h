#ifndef __CPUCTRL_H__
#define __CPUCTRL_H__

#define cpuctrl_init() 
#define save_system_regs()
#define cpuctrl_deinit()
#define set_display_clock_div(D)
#define set_FCLK(M)
#define set_920_Div(D)
#define set_DCLK_Div(D)
#define Disable_940()
#define gp2x_video_wait_vsync()

#endif
