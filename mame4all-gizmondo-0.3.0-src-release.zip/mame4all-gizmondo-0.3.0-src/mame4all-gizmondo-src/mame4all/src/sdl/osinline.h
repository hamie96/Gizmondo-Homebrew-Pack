#ifndef _OSINLINE_H_
#define _OSINLINE_H_


#ifdef USE_FLOAT_VEC
#define vec_mult(PRM1,PRM2) (int)(((double)param1)*((double)param2))
#define vec_div(PRM1,PRM2) (int)(((double)param1)/((double)param2))
#endif


#endif
