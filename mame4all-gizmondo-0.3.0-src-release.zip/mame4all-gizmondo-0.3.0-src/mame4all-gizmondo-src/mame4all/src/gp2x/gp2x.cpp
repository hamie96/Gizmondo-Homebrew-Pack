/***************************************************************************

  osdepend.c

  OS dependant stuff (display handling, keyboard scan...)
  This is the only file which should me modified in order to port the
  emulator to a different system.

***************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "driver.h"
#include "gp2x_mame.h"
#include "gp2x_menu.h"

#if !defined(GP2X) && defined(USE_FILECACHE)
void filecache_init(void);
void filecache_disable(void);
#else
#define filecache_init()
#endif

int  msdos_init_seal (void);
int  msdos_init_sound(void);
void msdos_init_input(void);
void msdos_shutdown_sound(void);
void msdos_shutdown_input(void);

/* platform independent options go here */
struct GameOptions options;

/* Command Line Arguments Emulation */
char playgame[16] = "builtinn\0";

/* put here anything you need to do when the program is started. Return 0 if */
/* initialization was successful, nonzero otherwise. */
int osd_init(void)
{
#ifdef GP2X
	gp2x_text_log("GP2X Port Init...");
#endif
	if (msdos_init_sound())
		return 1;
	msdos_init_input();
	return 0;
}


/* put here cleanup routines to be executed when the program is terminated. */
void osd_exit(void)
{
	msdos_shutdown_sound();
	msdos_shutdown_input();
}


/* Get Command Line Options */
static __inline void parse_cmdline (int myargc, char **myargv, struct GameOptions *options, int game_index)
{
	/* from sound.c */
	extern int soundcard;

	/* from gp2x_menu.c */
	extern int gp2x_frameskip;
	extern int gp2x_sound_enable;

	options->frameskip = gp2x_frameskip; /* 0,1,2,3... */
	options->norotate  = 0;
	options->ror       = 0;
	options->rol       = 0;
	options->flipx     = 0;
	options->flipy     = 0; 

	/* read sound configuration */
	soundcard=gp2x_sound_enable; /* 1 sound, 0 not emulated sound, 2 no sound but emulated, 3 accurate */

	options->samplerate = DEFAULT_SAMPLE_RATE;
	options->samplebits = 16;

	/* misc configuration */
	options->cheat = 0;
}

int main(int argc,char **argv)
{
	char text[64];
	int res, i, j, game_index;

	/* GP2X Video Init */
	gp2x_video_init();

	/* Set Video Mode */
	SetVideoScaling(320,320,240);
	
	/* Intro screen */
	gp2x_intro_screen();

	/* Initialize Game Listings */
 	game_list_init();
 	
	while(1) {

#ifdef GP2X
		/* Disable Scaling / Stretching */
		SetVideoScaling(320,320,240);
		gp2x_rotate=0;
#endif
		
		/* Init Extended Memory Access */
		gp2x_malloc_init();

		/* Select Game */
		select_game(playgame); 

		/* Initialize the audio library */
		msdos_init_seal();
		
		/* Restore MAME Palette */
		gp2x_mame_palette();
		
		/* Set Log Messages start at row 0 */
		gp2x_gamelist_zero();

		/* Single Video Buffer for Log Messages */
		gp2x_clear_screen();

		game_index = -1;

		/* do we have a driver for this? */
		for (i = 0; drivers[i] && (game_index == -1); i++)
		{
			if (strcasecmp(playgame,drivers[i]->name) == 0)
			{
				game_index = i;
				break;
			}
		}
	
		if (game_index == -1)
		{
			sprintf(text,"Game \"%s\" not supported\0",playgame);
			gp2x_text_log(text);
			while(1); /* MAME never ends xD */
		}

		/* parse generic (os-independent) options */
		parse_cmdline (argc, argv, &options, game_index);
	
		{	/* Mish:  I need sample rate initialised _before_ rom loading for optional rom regions */
			extern int soundcard;

			if (soundcard == 0) {    /* silence, this would be -1 if unknown in which case all roms are loaded */
				Machine->sample_rate = 0; /* update the Machine structure to show that sound is disabled */
				options.samplerate=0;
			}
		}

		sprintf(text,"Loading \"%s\"...",drivers[game_index]->description);
		gp2x_text_log(text);
	
		/* go for it */
		filecache_init();
		res = run_game (game_index , &options);
		
#if !defined(GP2X) && defined(USE_FILECACHE)
		if ( res != 0)
		{
			gp2x_text_log("Retrying without filecache...");
			filecache_disable();
			res = run_game (game_index , &options);
		}
#endif
		/* Error? */
		if( res != 0 )
		{
			gp2x_text_log("LOAD FAILED: Press A button...");
			while (!(gp2x_joystick_read()&GP2X_A));
		}

	} /* MAME never ends xD */
}
