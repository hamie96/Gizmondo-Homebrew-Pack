#include "driver.h"

void fade_me(void);

unsigned long ExKey;
#ifndef GP2X
#define ExKey1 ExKey
unsigned long ExKey2;
unsigned long ExKey3;
unsigned long ExKey4;
#endif

struct KeySettings keySettings = {
	GP2X_A,
	GP2X_X,
	GP2X_B,
	GP2X_Y,
	GP2X_L,
	GP2X_R,
	GP2X_VOL_UP,
	GP2X_VOL_DOWN,
	GP2X_PUSH,
	GP2X_START,
	0,
	0,
	0
};
struct KeySettings *key_settings = &keySettings;

int enable_trak_read=1;

void msdos_init_input (void)
{
	extern char playgame[16];
	osd_poll_joystick();
	
	/* Disable Trak Read ? Franxis 05-05-2006 */
	if ( (strcasecmp(playgame,"hbarrel")==0) || (strcasecmp(playgame,"hbarrelj")==0) ||
		(strcasecmp(playgame,"midres")==0) || (strcasecmp(playgame,"midresj")==0) ||
		(strcasecmp(playgame,"tnk3")==0) ||
		(strcasecmp(playgame,"ikari")==0) || (strcasecmp(playgame,"ikarijp")==0) || (strcasecmp(playgame,"ikarijpb")==0) ||
		(strcasecmp(playgame,"victroad")==0) || (strcasecmp(playgame,"dogosoke")==0) ||
		(strcasecmp(playgame,"gwar")==0) || (strcasecmp(playgame,"bermudat")==0) )
		enable_trak_read=0;
	else
		enable_trak_read=1;
}

void msdos_shutdown_input(void) { }


/*
 * Check if a key is pressed. The keycode is the standard PC keyboard
 * code, as defined in osdepend.h. Return 0 if the key is not pressed,
 * nonzero otherwise. Handle pseudo keycodes.
 */
int osd_key_pressed(int keycode)
{
	switch (keycode)
       	{
#ifdef GP2X
       		case OSD_KEY_CANCEL:
       			return ((ExKey & GP2X_L) && (ExKey & GP2X_R) && (ExKey & GP2X_PUSH));
    		case OSD_KEY_RESET_MACHINE:
    			return ((ExKey & GP2X_START) && (ExKey & GP2X_SELECT));
       		case OSD_KEY_PAUSE:
       		case OSD_KEY_UNPAUSE:
			return ((ExKey & GP2X_L) && (ExKey & GP2X_R));
#else
		case OSD_KEY_RESET_MACHINE:
			return ((ExKey & GP2X_PUSH) && (ExKey & GP2X_L));
       		case OSD_KEY_CANCEL:
			{
				static int cuenta=0;
				if ((ExKey & GP2X_PUSH)&&(!(ExKey & GP2X_L)))
				{
					osd_mute_sound();
#ifdef DREAMCAST
					if (cuenta>8)
					{
						cuenta=0;
						fade_me();
						return 1;
					}
					else
						cuenta++;
#else
					fade_me();
					return 1;
#endif
				}
				else
				{
					if (cuenta)
					{
						osd_unmute_sound();
						cuenta=0;
					}
				}
			}
			return 0;
       		case OSD_KEY_PAUSE:
       		case OSD_KEY_UNPAUSE:
			return (ExKey & GP2X_PUSH);
#endif
		case OSD_KEY_1: /* 1 Player Start == Start Button */
#ifdef GP2X
			return ( (ExKey & GP2X_START) && !(ExKey & GP2X_SELECT) && !(ExKey & GP2X_UP) && !(ExKey & GP2X_RIGHT) && !(ExKey & GP2X_DOWN) );
#else
			return (ExKey1 & GP2X_START);
#endif
		case OSD_KEY_2: /* 2 Player Start == Joystick UP + Start Button */
#ifdef GP2X
			return ( (ExKey & GP2X_START) && !(ExKey & GP2X_SELECT) && (ExKey & GP2X_UP) && !(ExKey & GP2X_RIGHT) && !(ExKey & GP2X_DOWN) );
#else
			return (ExKey2 & GP2X_START);
#endif
		case OSD_KEY_7: /* 3 Player Start == Joystick RIGHT + Start Button */
#ifdef GP2X
			return ( (ExKey & GP2X_START) && !(ExKey & GP2X_SELECT) && !(ExKey & GP2X_UP) && (ExKey & GP2X_RIGHT) && !(ExKey & GP2X_DOWN) );
#else
			return (ExKey3 & GP2X_START);
#endif
		case OSD_KEY_8: /* 4 Player Start == Joystick DOWN + Start Button */
#ifdef GP2X
			return ( (ExKey & GP2X_START) && !(ExKey & GP2X_SELECT) && !(ExKey & GP2X_UP) && !(ExKey & GP2X_RIGHT) && (ExKey & GP2X_DOWN) );
#else
			return (ExKey4 & GP2X_START);
#endif
		case OSD_KEY_3: /* Coin A == L Button */
#ifdef GP2X
			return ( !(ExKey & GP2X_START) && (ExKey & GP2X_SELECT) && !(ExKey & GP2X_UP) && !(ExKey & GP2X_RIGHT) && !(ExKey & GP2X_DOWN) );
#else
			return (ExKey1 & GP2X_SELECT);
#endif
		case OSD_KEY_4:	/* Coin B == L Button + Joystick UP */	
#ifdef GP2X
			return ( !(ExKey & GP2X_START) && (ExKey & GP2X_SELECT) && (ExKey & GP2X_UP) && !(ExKey & GP2X_RIGHT) && !(ExKey & GP2X_DOWN) );
#else
			return (ExKey2 & GP2X_SELECT);
#endif
		case OSD_KEY_5: /* Coin C == L Button + Joystick RIGHT */
#ifdef GP2X
			return ( !(ExKey & GP2X_START) && (ExKey & GP2X_SELECT) && !(ExKey & GP2X_UP) && (ExKey & GP2X_RIGHT) && !(ExKey & GP2X_DOWN) );
#else
			return (ExKey3 & GP2X_SELECT);
#endif
		case OSD_KEY_6: /* Coin D == L Button + Joystick DOWN */
#ifdef GP2X
			return ( !(ExKey & GP2X_START) && (ExKey & GP2X_SELECT) && !(ExKey & GP2X_UP) && !(ExKey & GP2X_RIGHT) && (ExKey & GP2X_DOWN) );
#else
			return (ExKey4 & GP2X_SELECT);
#endif
    		default:
			return 0;
        	}
}


void osd_poll_joystick(void)
{ 
#if defined (GP2X) || defined (GIZMONDO)
	ExKey=gp2x_joystick_read();
#else
	ExKey1=gp2x_joystick_read_n(1);
	ExKey2=gp2x_joystick_read_n(2);
	ExKey3=gp2x_joystick_read_n(3);
	ExKey4=gp2x_joystick_read_n(4);
#endif
}

#if !defined (GP2X) && !defined (GIZMONDO)
#define GET_JOY_FIRE(NJOY,MFIRE) \
			if (key_settings->JOY_FIRE##NJOY##_AUTO) { \
				f##MFIRE[(NJOY-1)]=(ExKey##NJOY & key_settings->JOY_FIRE##MFIRE); \
				if (!f##MFIRE[(NJOY-1)]) { c##MFIRE[(NJOY-1)]=0; return 0; } c##MFIRE[(NJOY-1)]++; if (c##MFIRE[(NJOY-1)]>=8) { c##MFIRE[(NJOY-1)]=0; return 0; } if (c##MFIRE[(NJOY-1)]=4) {return 0; } return 1; \
			} \
			else \
				return (ExKey##NJOY & key_settings->JOY_FIRE##MFIRE);

#define CASE_JOY_FIRES(MFIRE) \
		case OSD_JOY_FIRE##MFIRE: \
			GET_JOY_FIRE(1,MFIRE) \
		case OSD_JOY2_FIRE##MFIRE: \
			GET_JOY_FIRE(2,MFIRE) \
		case OSD_JOY3_FIRE##MFIRE: \
			GET_JOY_FIRE(3,MFIRE)
#endif

/* check if the joystick is moved in the specified direction, defined in */
/* osdepend.h. Return 0 if it is not pressed, nonzero otherwise. */
int osd_joy_pressed(int joycode)
{
#if defined (GP2X) || defined (GIZMONDO)
	static int f1,f2,f3,c1=0,c2=0,c3=0; /* For Auto-fire */
#else
	static int f1[4]={0,0,0,0};
	static int f2[4]={0,0,0,0};
	static int f3[4]={0,0,0,0};
	static int c1[4]={0,0,0,0};
	static int c2[4]={0,0,0,0};
	static int c3[4]={0,0,0,0}; /* For Auto-fire */
#endif
	switch (joycode)
	{
#if defined (GP2X) || defined (GIZMONDO)
		case OSD_JOY_LEFT:
		case OSD_JOY2_LEFT:
		case OSD_JOY3_LEFT:
		case OSD_JOY4_LEFT:
		  	if (gp2x_rotate&1)
		  		return (ExKey & GP2X_UP);
		  	else
		  		return (ExKey & GP2X_LEFT);
#else
		case OSD_JOY_LEFT:
		  		return (ExKey1 & GP2X_LEFT);
		case OSD_JOY2_LEFT:
		  		return (ExKey2 & GP2X_LEFT);
		case OSD_JOY3_LEFT:
		  		return (ExKey3 & GP2X_LEFT);
		case OSD_JOY4_LEFT:
		  		return (ExKey4 & GP2X_LEFT);
#endif
#if defined (GP2X) || defined (GIZMONDO)
		case OSD_JOY_RIGHT:
		case OSD_JOY2_RIGHT:
		case OSD_JOY3_RIGHT:
		case OSD_JOY4_RIGHT:
		  	if (gp2x_rotate&1)
		  		return (ExKey & GP2X_DOWN);
		  	else
			  	return (ExKey & GP2X_RIGHT);
#else
		case OSD_JOY_RIGHT:
			  	return (ExKey1 & GP2X_RIGHT);
		case OSD_JOY2_RIGHT:
			  	return (ExKey2 & GP2X_RIGHT);
		case OSD_JOY3_RIGHT:
			  	return (ExKey3 & GP2X_RIGHT);
		case OSD_JOY4_RIGHT:
			  	return (ExKey4 & GP2X_RIGHT);
#endif
#if defined (GP2X) || defined (GIZMONDO)
		case OSD_JOY_UP:
		case OSD_JOY2_UP:
		case OSD_JOY3_UP:
		case OSD_JOY4_UP:
		  	if (gp2x_rotate&1)
			  	return (ExKey & GP2X_RIGHT);
		  	else
			  	return (ExKey & GP2X_UP);
#else
		case OSD_JOY_UP:
			  	return (ExKey1 & GP2X_UP);
		case OSD_JOY2_UP:
			  	return (ExKey2 & GP2X_UP);
		case OSD_JOY3_UP:
			  	return (ExKey3 & GP2X_UP);
		case OSD_JOY4_UP:
			  	return (ExKey4 & GP2X_UP);
#endif
#if defined (GP2X) || defined (GIZMONDO)
		case OSD_JOY_DOWN:
		case OSD_JOY2_DOWN:
		case OSD_JOY3_DOWN:
		case OSD_JOY4_DOWN:
		  	if (gp2x_rotate&1)
		  		return (ExKey & GP2X_LEFT);
		  	else 
		  		return (ExKey & GP2X_DOWN);
#else
		case OSD_JOY_DOWN:
		  		return (ExKey1 & GP2X_DOWN);
		case OSD_JOY2_DOWN:
		  		return (ExKey2 & GP2X_DOWN);
		case OSD_JOY3_DOWN:
		  		return (ExKey3 & GP2X_DOWN);
		case OSD_JOY4_DOWN:
		  		return (ExKey4 & GP2X_DOWN);
#endif
#if defined (GP2X) || defined (GIZMONDO)
		case OSD_JOY_FIRE1:
		case OSD_JOY2_FIRE1:
		case OSD_JOY3_FIRE1:
		case OSD_JOY4_FIRE1:
		  	if (key_settings->JOY_FIRE1_AUTO) {
		  		/* Auto-fire */
		  		if (gp2x_rotate&1)
	  				f1=((ExKey & key_settings->JOY_FIRE1)||(ExKey & GP2X_VOL_UP));
	  			else
	  				f1=(ExKey & key_settings->JOY_FIRE1);
				if (!f1) { c1=0; return 0; } c1++; if (c1>=8) { c1=0; return 0; } if (c1>=4) {return 0; } return 1;
		  	} else {
		  		if (gp2x_rotate&1)
	  				return ((ExKey & key_settings->JOY_FIRE1)||(ExKey & GP2X_VOL_UP));
	  			else
	  				return (ExKey & key_settings->JOY_FIRE1);
	  		}
		case OSD_JOY_FIRE2:
		case OSD_JOY2_FIRE2:
		case OSD_JOY3_FIRE2:
		case OSD_JOY4_FIRE2:
		  	if (key_settings->JOY_FIRE2_AUTO) {
		  		/* Auto-fire */
	  			if (gp2x_rotate&1)
  					f2=((ExKey & key_settings->JOY_FIRE2)||(ExKey & GP2X_VOL_DOWN));
  				else
				  	f2=(ExKey & key_settings->JOY_FIRE2);
				if (!f2) { c2=0; return 0; } c2++; if (c2>=8) { c2=0; return 0; } if (c2>=4) {return 0; } return 1;
		  	} else {
	  			if (gp2x_rotate&1)
  					return ((ExKey & key_settings->JOY_FIRE2)||(ExKey & GP2X_VOL_DOWN));
  				else
				  	return (ExKey & key_settings->JOY_FIRE2);
			}
		case OSD_JOY_FIRE3:
		case OSD_JOY2_FIRE3:
		case OSD_JOY3_FIRE3:
		case OSD_JOY4_FIRE3:
		  	if (key_settings->JOY_FIRE3_AUTO) {
		  		/* Auto-fire */
		  		f3=(ExKey & key_settings->JOY_FIRE3);
				if (!f3) { c3=0; return 0; } c3++; if (c3>=8) { c3=0; return 0; } if (c3>=4) {return 0; } return 1;
		  	} else {
	  			return (ExKey & key_settings->JOY_FIRE3);
	  		}
#else
		CASE_JOY_FIRES(1)
		CASE_JOY_FIRES(2)
		CASE_JOY_FIRES(3)
#endif
#if defined (GP2X) || defined (GIZMONDO)
		case OSD_JOY_FIRE4:
		case OSD_JOY2_FIRE4:
		case OSD_JOY3_FIRE4:
		case OSD_JOY4_FIRE4:
		  	return (ExKey & key_settings->JOY_FIRE4);
#else
		case OSD_JOY_FIRE4:
		  	return (ExKey1 & key_settings->JOY_FIRE4);
		case OSD_JOY2_FIRE4:
		  	return (ExKey2 & key_settings->JOY_FIRE4);
		case OSD_JOY3_FIRE4:
		  	return (ExKey3 & key_settings->JOY_FIRE4);
		case OSD_JOY4_FIRE4:
		  	return (ExKey4 & key_settings->JOY_FIRE4);
#endif
#if defined (GP2X) || defined (GIZMONDO)
		case OSD_JOY_FIRE5:
		case OSD_JOY2_FIRE5:
		case OSD_JOY3_FIRE5:
		case OSD_JOY4_FIRE5:
		  	return (ExKey & key_settings->JOY_FIRE5);
#else
		case OSD_JOY_FIRE5:
		  	return (ExKey1 & key_settings->JOY_FIRE5);
		case OSD_JOY2_FIRE5:
		  	return (ExKey2 & key_settings->JOY_FIRE5);
		case OSD_JOY3_FIRE5:
		  	return (ExKey3 & key_settings->JOY_FIRE5);
		case OSD_JOY4_FIRE5:
		  	return (ExKey4 & key_settings->JOY_FIRE5);
#endif
#if defined (GP2X) || defined (GIZMONDO)
		case OSD_JOY_FIRE6:
		case OSD_JOY2_FIRE6:
		case OSD_JOY3_FIRE6:
		case OSD_JOY4_FIRE6:
		  	return (ExKey & key_settings->JOY_FIRE6);
#else
		case OSD_JOY_FIRE6:
		  	return (ExKey1 & key_settings->JOY_FIRE6);
		case OSD_JOY2_FIRE6:
		  	return (ExKey2 & key_settings->JOY_FIRE6);
		case OSD_JOY3_FIRE6:
		  	return (ExKey3 & key_settings->JOY_FIRE6);
		case OSD_JOY4_FIRE6:
		  	return (ExKey4 & key_settings->JOY_FIRE6);
#endif
#if defined (GP2X) || defined (GIZMONDO)
		case OSD_JOY_FIRE7:
		case OSD_JOY2_FIRE7:
		case OSD_JOY3_FIRE7:
		case OSD_JOY4_FIRE7:
		  	return (ExKey & key_settings->JOY_FIRE7);
#else
		case OSD_JOY_FIRE7:
		  	return (ExKey1 & key_settings->JOY_FIRE7);
		case OSD_JOY2_FIRE7:
		  	return (ExKey2 & key_settings->JOY_FIRE7);
		case OSD_JOY3_FIRE7:
		  	return (ExKey3 & key_settings->JOY_FIRE7);
		case OSD_JOY4_FIRE7:
		  	return (ExKey4 & key_settings->JOY_FIRE7);
#endif
#if defined (GP2X) || defined (GIZMONDO)
		case OSD_JOY_FIRE8:
		case OSD_JOY2_FIRE8:
		case OSD_JOY3_FIRE8:
		case OSD_JOY4_FIRE8:
		  	return (ExKey & key_settings->JOY_FIRE8);
#else
		case OSD_JOY_FIRE8:
		  	return (ExKey1 & key_settings->JOY_FIRE8);
		case OSD_JOY2_FIRE8:
		  	return (ExKey2 & key_settings->JOY_FIRE8);
		case OSD_JOY3_FIRE8:
		  	return (ExKey3 & key_settings->JOY_FIRE8);
		case OSD_JOY4_FIRE8:
		  	return (ExKey4 & key_settings->JOY_FIRE8);
#endif
#if defined (GP2X) || defined (GIZMONDO)
		case OSD_JOY_FIRE9:
		case OSD_JOY2_FIRE9:
		case OSD_JOY3_FIRE9:
		case OSD_JOY4_FIRE9:
		  	return (ExKey & key_settings->JOY_FIRE9);
#else
#endif
		case OSD_JOY_FIRE9:
		  	return (ExKey1 & key_settings->JOY_FIRE9);
		case OSD_JOY2_FIRE9:
		  	return (ExKey2 & key_settings->JOY_FIRE9);
		case OSD_JOY3_FIRE9:
		  	return (ExKey3 & key_settings->JOY_FIRE9);
		case OSD_JOY4_FIRE9:
		  	return (ExKey4 & key_settings->JOY_FIRE9);
#if defined (GP2X) || defined (GIZMONDO)
		case OSD_JOY_FIRE10:
		case OSD_JOY2_FIRE10:
		case OSD_JOY3_FIRE10:
		case OSD_JOY4_FIRE10:
		  	return (ExKey & key_settings->JOY_FIRE10);
#else
		case OSD_JOY_FIRE10:
		  	return (ExKey1 & key_settings->JOY_FIRE10);
		case OSD_JOY2_FIRE10:
		  	return (ExKey2 & key_settings->JOY_FIRE10);
		case OSD_JOY3_FIRE10:
		  	return (ExKey3 & key_settings->JOY_FIRE10);
		case OSD_JOY4_FIRE10:
		  	return (ExKey4 & key_settings->JOY_FIRE10);
#endif
#if defined (GP2X) || defined (GIZMONDO)
		case OSD_JOY_FIRE:
		case OSD_JOY2_FIRE:
		case OSD_JOY3_FIRE:
		case OSD_JOY4_FIRE:
			return ( (ExKey & key_settings->JOY_FIRE1) || (ExKey & key_settings->JOY_FIRE2) || (ExKey & key_settings->JOY_FIRE3) ||
				(ExKey & key_settings->JOY_FIRE4) || (ExKey & key_settings->JOY_FIRE5) || (ExKey & key_settings->JOY_FIRE6) );
#else
		case OSD_JOY_FIRE:
			return ( (ExKey1 & key_settings->JOY_FIRE1) || (ExKey1 & key_settings->JOY_FIRE2) || (ExKey1 & key_settings->JOY_FIRE3) ||
				(ExKey1 & key_settings->JOY_FIRE4) || (ExKey1 & key_settings->JOY_FIRE5) || (ExKey1 & key_settings->JOY_FIRE6) );
		case OSD_JOY2_FIRE:
			return ( (ExKey2 & key_settings->JOY_FIRE1) || (ExKey2 & key_settings->JOY_FIRE2) || (ExKey2 & key_settings->JOY_FIRE3) ||
				(ExKey2 & key_settings->JOY_FIRE4) || (ExKey2 & key_settings->JOY_FIRE5) || (ExKey2 & key_settings->JOY_FIRE6) );
		case OSD_JOY3_FIRE:
			return ( (ExKey3 & key_settings->JOY_FIRE1) || (ExKey3 & key_settings->JOY_FIRE2) || (ExKey3 & key_settings->JOY_FIRE3) ||
				(ExKey3 & key_settings->JOY_FIRE4) || (ExKey3 & key_settings->JOY_FIRE5) || (ExKey3 & key_settings->JOY_FIRE6) );
		case OSD_JOY4_FIRE:
			return ( (ExKey4 & key_settings->JOY_FIRE1) || (ExKey4 & key_settings->JOY_FIRE2) || (ExKey4 & key_settings->JOY_FIRE3) ||
				(ExKey4 & key_settings->JOY_FIRE4) || (ExKey4 & key_settings->JOY_FIRE5) || (ExKey4 & key_settings->JOY_FIRE6) );
#endif
		default: 
			return 0;
	}
}

int pos_analog_x=0;
int pos_analog_y=0;

/* return a value in the range -128 .. 128 (yes, 128, not 127) */
void osd_analogjoy_read(int *analog_x, int *analog_y)
{
#if defined (GP2X) || defined (GIZMONDO)
	if (gp2x_rotate&1) {
		if( (!(ExKey & GP2X_UP)) && (!(ExKey & GP2X_DOWN)) ) { 
			pos_analog_x=0;
		} else {
			if(ExKey & GP2X_UP) pos_analog_x-=5;
			if(ExKey & GP2X_DOWN) pos_analog_x+=5;
		}
		if( (!(ExKey & GP2X_LEFT)) && (!(ExKey & GP2X_RIGHT)) ) { 
			pos_analog_y=0;
		} else {
		  	if(ExKey & GP2X_RIGHT) pos_analog_y-=5; 
			if(ExKey & GP2X_LEFT) pos_analog_y+=5;
		}
	} else
#endif
	{
		if( (!(ExKey & GP2X_LEFT)) && (!(ExKey & GP2X_RIGHT)) ) {
			pos_analog_x=0;
		} else {
			if(ExKey & GP2X_LEFT) pos_analog_x-=5;
	  		if(ExKey & GP2X_RIGHT) pos_analog_x+=5;
		}
		if( (!(ExKey & GP2X_UP)) && (!(ExKey & GP2X_DOWN)) ) {
			pos_analog_y=0;
		} else {
	  		if(ExKey & GP2X_UP) pos_analog_y-=5; 
	 		if(ExKey & GP2X_DOWN) pos_analog_y+=5;
	 	}
	}
	
	if (pos_analog_x<-128) pos_analog_x=-128;
	if (pos_analog_x>128) pos_analog_x=128;
	if (pos_analog_y<-128) pos_analog_y=-128;
	if (pos_analog_y>128) pos_analog_y=128;
	
	*analog_x = pos_analog_x;
	*analog_y = pos_analog_y;

}

void osd_trak_read(int *deltax,int *deltay)
{
	*deltax = *deltay = 0;
	if (!enable_trak_read) return; /* Franxis 05-05-2006 */
	
#if defined (GP2X) || defined (GIZMONDO)
	if (gp2x_rotate&1) {
		if(ExKey & GP2X_UP) *deltax=-20;
		if(ExKey & GP2X_DOWN) *deltax=20;
	  	if(ExKey & GP2X_RIGHT) *deltay=20; 
		if(ExKey & GP2X_LEFT) *deltay=-20;
	} else
#endif
	{
		if(ExKey & GP2X_LEFT) *deltax=-20;
	  	if(ExKey & GP2X_RIGHT) *deltax=20;
	  	if(ExKey & GP2X_UP) *deltay=20; 
	 	if(ExKey & GP2X_DOWN) *deltay=-20;
	}
}

void osd_led_w(int led,int on) { }
