#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "driver.h"
#include "gp2x_mame.h"
#include "gfx/gp2xmenu.h"
#include "gfx/gp2xsplash.h"

#ifndef MAME4ALL_CPU_CLOCK
#define MAME4ALL_CPU_CLOCK 80
#endif

#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>

static int game_num=2048;
static int game_num_avail=0;
static char game_avail[2048];
static int last_game_selected=0;

extern int gp2x_frameskip;
extern int gp2x_frameskip_auto;
extern int gp2x_double_buffer;
extern int gp2x_vsync;
int gp2x_sound_enable = 1;
int gp2x_clock_cpu=MAME4ALL_CPU_CLOCK; 			// Clock option for CPU's 
int gp2x_clock_sound=MAME4ALL_CPU_CLOCK; 		// Clock option for Audio CPU's 
int gp2x_freq=200;			// GP2X Clock Frequency 
int gp2x_save_config=0;			// Save Configuration 

extern int x_sensitivity;
extern int y_sensitivity;
extern int x_reversed;
extern int y_reversed;
extern struct KeySettings *key_settings;

char gp2x_path_mame[24]="\0";

void load_bmp_8bpp(unsigned char *out, unsigned char *in) 
{
	int i,x,y;
	unsigned char r,g,b,c;

	in+=14; /* Skip HEADER */
	in+=40; /* Skip INFOHD */
	
	/* Set Palette */
	for (i=0;i<256;i++) {
		b=*in++;
		g=*in++;
		r=*in++;
		c=*in++;
		gp2x_video_color8(i,r,g,b);
	}
	gp2x_video_setpalette();
	/* Set Bitmap */	
	for (y=239;y!=-1;y--) {
		for (x=0;x<320;x++) {
			*out++=in[x+y*320];
		}
	}
}

void gp2x_intro_screen(void) {
	char name[256];
	FILE *f;
	gp2x_video_flip();

	/* Problem with relative paths in some GP2X? */
	f=fopen("/mnt/sd/mamegp2x/mame_gp2x.gpe","rb");
	if (f) {
		fclose(f);
		strcpy(gp2x_path_mame,"/mnt/sd/mamegp2x/\0");
	}

#ifndef NO_SPLASH
	sprintf(name,"%sskins/gp2xsplash.bmp",gp2x_path_mame);
	f=fopen(name,"rb");
	if (f) {
		fread(gp2xsplash_bmp,1,77878,f);
		fclose(f);
	}
	load_bmp_8bpp(gp2x_screen8,gp2xsplash_bmp);
#endif
	gp2x_video_flip();
	
	sprintf(name,"%sskins/gp2xmenu.bmp",gp2x_path_mame);
	f=fopen(name,"rb");
	if (f) {
		fread(gp2xmenu_bmp,1,77878,f);
		fclose(f);
	}
#if !defined(GP2X) && !defined(NO_SPLASH)
	gp2x_timer_delay(2000);
	{
		int i,j;
		unsigned char *pal=&gp2xsplash_bmp[40+14];
		unsigned char *dat=&gp2xsplash_bmp[40+14+(256*4)];

		for(i=0;i<320*240;i++)
		{
			unsigned char b=pal[(dat[i]*4)+0];
			unsigned char g=pal[(dat[i]*4)+1];
			unsigned char r=pal[(dat[i]*4)+2];
			unsigned med=r; med+=g; med+=b; med/=3;
			dat[i]=128+(med>>1)-1;
		}

		pal[0]=pal[1]=pal[2]=0;
		for(i=1;i<255;i++)
		{
			pal[(i*4)+0]=pal[(i*4)+1]=pal[(i*4)+2]=255-i;
#ifdef MAME4ALL_GOLD
			if ((((unsigned)pal[(i*4)+1])<<1)<255) pal[(i*4)+1]<<=1; 
#else
#ifdef MAME4ALL_CLASSIC
			if ((((unsigned)pal[(i*4)+2])<<1)<255) pal[(i*4)+2]<<=1; 
#else
			if ((((unsigned)pal[(i*4)+0])<<1)<255) pal[(i*4)+0]<<=1; 
#endif
#endif
		}
		pal[(255*4)+0]=pal[(255*4)+1]=pal[(255*4)+2]=255;
	}
#endif
}

/* Initialize the list of available games in the SD */
#ifdef USE_OLD_LIST_INIT
void game_list_init(void) {
	char name[256];
	struct stat stat_buffer;
	unsigned int c;
	/* Check Available Games */
	for (c=0;(c<game_num && drivers[c]);c++) {

		/*
		sprintf(name,"%sroms/%s\0", gp2x_path_mame, drivers[c]->name);
		if (stat(name,&stat_buffer)==0)	{	
			game_avail[c]=1;
			game_num_avail++;
			continue;
		}
		*/
#ifdef GIZMONDO
	  sprintf(name, "\\SD Card\\mame4all\\roms\\%s.zip", drivers[c]->name);
#else		
		sprintf(name,"%sroms/%s.zip\0", gp2x_path_mame, drivers[c]->name);
#endif
		if (stat(name,&stat_buffer)==0)	{
			game_avail[c]=1;
			game_num_avail++;
			continue;
		}
	}
}
#else
void game_list_init(void) {
#ifdef DREAMCAST
	DIR *d=opendir(ROM_PREFIX "roms");
#else
#ifdef GP2X
	char name[256];
	sprintf(name,"%sroms\0",gp2x_path_mame);
	DIR *d=opendir(name);
#else
#ifdef GIZMONDO
	DIR *d=opendir("\\SD Card\\mame4all\\roms");
#else
	DIR *d=opendir("roms");
#endif
#endif
#endif
	if (d)
	{
		struct dirent *actual=readdir(d);
		int min=0;
		int max_total, max;
		int i;
		char **games=(char **)gp2x_malloc(game_num*sizeof(char *));
		for(i=0;i<game_num && drivers[i];i++)
		{
			games[i]=(char *)gp2x_malloc(32);
			strncpy(games[i],drivers[i]->name,32-5);
			strcat(games[i],".zip\0");
		}
		max=max_total=i;
		while(actual)
		{
			int encontrado=0;
			for(i=min;i<max;i++)
				if (!stricmp(actual->d_name,games[i])){
					game_avail[i]=1;
					game_num_avail++;
					if (i==min)
						min=i+1;
					else
					if (i==max)
						max=i-1;
//					puts(drivers[i]->description);
					encontrado=1;
					break;
				}
/*
			if (!encontrado)
				printf("SOBRA:%s\n",actual->d_name);
*/
			actual=readdir(d);
		}
		for(i=0;i<max_total;i++)
		{
/*
			if (!game_avail[i])
				printf("FALTA:%s\n",games[i]);
*/
			gp2x_free(games[i]);
		}
//		printf("TOTAL %i roms\n",max_total);
		gp2x_free(games);
		closedir(d);
	}
}
#endif

static void game_list_view(int *pos) {

	int i;
	int view_pos;
	int aux_pos=0;
	int screen_y = 45;
	int screen_x = 38;

	/* Draw background image */
	load_bmp_8bpp(gp2x_screen8,gp2xmenu_bmp);

	/* Check Limits */
	if (*pos<0)
		*pos=game_num_avail-1;
	if (*pos>(game_num_avail-1))
		*pos=0;
					   
	/* Set View Pos */
	if (*pos<10) {
		view_pos=0;
	} else {
		if (*pos>game_num_avail-11) {
			view_pos=game_num_avail-21;
			view_pos=(view_pos<0?0:view_pos);
		} else {
			view_pos=*pos-10;
		}
	}

	/* Show List */
	for (i=0;i<game_num;i++) {
		if (game_avail[i]==1) {
			if (aux_pos>=view_pos && aux_pos<=view_pos+20) {
				gp2x_gamelist_text_out( screen_x, screen_y, (char *)drivers[i]->description );
				if (aux_pos==*pos) {
					gp2x_gamelist_text_out( screen_x-10, screen_y,">" );
					gp2x_gamelist_text_out( screen_x-13, screen_y-1,"-" );
				}
				screen_y+=8;
			}
			aux_pos++;
		}
	}

}

static void game_list_select (int index, char *game) {
	int i;
	int aux_pos=0;
	for (i=0;i<game_num;i++) {
		if (game_avail[i]==1) {
			if(aux_pos==index) {
				strcpy(game,drivers[i]->name);
			}
			aux_pos++;
		   }
	}
}

static char *game_list_description (int index) {
	int i;
	int aux_pos=0;
	for (i=0;i<game_num;i++) {
		if (game_avail[i]==1) {
			if(aux_pos==index) {
				return((char *)drivers[i]->description);
			}
			aux_pos++;
		   }
	}
	return ((char *)0);
}

static void button_text(unsigned long button,char *text)
{
	if (button==GP2X_A) {
#ifdef GP2X
		strcpy(text,"BUTTON A\0");
#else
		strcpy(text,"BUTTON X\0");
#endif
	} else if (button==GP2X_X) {
#ifdef GP2X
		strcpy(text,"BUTTON X\0");
#else
		strcpy(text,"BUTTON A\0");
#endif
	} else if (button==GP2X_B) {
		strcpy(text,"BUTTON B\0");
	} else if (button==GP2X_Y) {
		strcpy(text,"BUTTON Y\0");
	} else if (button==GP2X_L) {
		strcpy(text,"BUTTON L\0");
	} else if (button==GP2X_R) {
		strcpy(text,"BUTTON R\0");
	} else if (button==GP2X_VOL_UP) {
		strcpy(text,"VOLUME UP\0");
	} else if (button==GP2X_VOL_DOWN) {
		strcpy(text,"VOLUME DOWN\0");
	} else if (button==GP2X_PUSH) {
		strcpy(text,"JOYPAD PUSH\0");
	} else if (button==GP2X_START) {
		strcpy(text,"START\0");
	} else if (button==GP2X_SELECT) {
		strcpy(text,"SELECT\0");
	}
}

static unsigned long button_next(unsigned long button,int next)
{
	if (button==GP2X_A) {
		if (next) return GP2X_B; else return GP2X_SELECT;
	} else if (button==GP2X_B) {
		if (next) return GP2X_X; else return GP2X_A;
	} else if (button==GP2X_X) {
		if (next) return GP2X_Y; else return GP2X_B;
	} else if (button==GP2X_Y) {
		if (next) return GP2X_L; else return GP2X_X;
	} else if (button==GP2X_L) {
		if (next) return GP2X_R; else return GP2X_Y;
	} else if (button==GP2X_R) {
		if (next) return GP2X_VOL_UP; else return GP2X_L;
	} else if (button==GP2X_VOL_UP) {
		if (next) return GP2X_VOL_DOWN; else return GP2X_R;
	} else if (button==GP2X_VOL_DOWN) {
		if (next) return GP2X_PUSH; else return GP2X_VOL_UP;
	} else if (button==GP2X_PUSH) {
		if (next) return GP2X_START; else return GP2X_VOL_DOWN;
	} else if (button==GP2X_START) {
		if (next) return GP2X_SELECT; else return GP2X_PUSH;
	} else if (button==GP2X_SELECT) {
		if (next) return GP2X_A; else return GP2X_START;
	}
	return 0;
}

static void controller_config(void)
{

	unsigned long ExKey=0;
	int selected_option=0;
	int x_Pos = 41;
	int y_Pos = 48;
	int options_count = 18;
	char text[64];
	int i;
	char* options[] = 		{	"FIRE01 Auto    = %s",
						"FIRE02 Auto    = %s",
						"FIRE03 Auto    = %s",
						"FIRE01         = %s",
						"FIRE02         = %s",
						"FIRE03         = %s",
						"FIRE04         = %s",
						"FIRE05         = %s",
						"FIRE06         = %s",
						"FIRE07         = %s",
						"FIRE08         = %s",
						"FIRE09         = %s",
						"FIRE10         = %s",
						"X Sensitivity  = %s",
						"X Reversed     = %s",
						"Y Sensitivity  = %s",
						"Y Reversed     = %s",
						"Back to Default Values"};
	
	while (1)
	{
		/* Draw background image */
		load_bmp_8bpp(gp2x_screen8,gp2xmenu_bmp);
		
		/* Draw the options */
		gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+0,options[0],key_settings->JOY_FIRE1_AUTO?"ON\0":"OFF\0");
		gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+8,options[1],key_settings->JOY_FIRE2_AUTO?"ON\0":"OFF\0");
		gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+16,options[2],key_settings->JOY_FIRE3_AUTO?"ON\0":"OFF\0");
		button_text(key_settings->JOY_FIRE1,text);
		gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+24,options[3],text);
		button_text(key_settings->JOY_FIRE2,text);
		gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+32,options[4],text);
		button_text(key_settings->JOY_FIRE3,text);
		gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+40,options[5],text);
		button_text(key_settings->JOY_FIRE4,text);
		gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+48,options[6],text);
		button_text(key_settings->JOY_FIRE5,text);
		gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+56,options[7],text);
		button_text(key_settings->JOY_FIRE6,text);
		gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+64,options[8],text);
		button_text(key_settings->JOY_FIRE7,text);
		gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+72,options[9],text);
		button_text(key_settings->JOY_FIRE8,text);
		gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+80,options[10],text);
		button_text(key_settings->JOY_FIRE9,text);
		gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+88,options[11],text);
		button_text(key_settings->JOY_FIRE10,text);
		gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+96,options[12],text);
		if (x_sensitivity!=-1)
			sprintf(text,"%d",x_sensitivity);
		else
			strcpy(text,"DEFAULT");
		gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+104,options[13],text);
		if (x_reversed)
			strcpy(text,"ON");
		else
			strcpy(text,"OFF");
		gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+112,options[14],text);
		if (y_sensitivity!=-1)
			sprintf(text,"%d",y_sensitivity);
		else
			strcpy(text,"DEFAULT");
		gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+120,options[15],text);
		if (y_reversed)
			strcpy(text,"ON");
		else
			strcpy(text,"OFF");
		gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+128,options[16],text);
		gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+136,options[17]);
		
		gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+152,"Press A or B to confirm");	

		/* Show currently selected item */
		gp2x_gamelist_text_out(x_Pos-16,y_Pos+(selected_option*8)," >");

		gp2x_video_flip();
		while(gp2x_joystick_read()&0x8c0ff55) { gp2x_timer_delay(150); }
		while(!(ExKey=gp2x_joystick_read()&0x8c0ff55)) { }

		if(ExKey & GP2X_DOWN){
			selected_option++;
			selected_option = selected_option % options_count;
		}
		else if(ExKey & GP2X_UP){
			selected_option--;
			if(selected_option<0)
				selected_option = options_count - 1;
		}
#ifdef GP2X
		else if(ExKey & GP2X_R || ExKey & GP2X_L){
#else
		else if(ExKey & GP2X_RIGHT || ExKey & GP2X_LEFT){
#endif
			switch(selected_option) {
				
				case 0: key_settings->JOY_FIRE1_AUTO=key_settings->JOY_FIRE1_AUTO?0:1; break;
				case 1: key_settings->JOY_FIRE2_AUTO=key_settings->JOY_FIRE2_AUTO?0:1; break;
				case 2: key_settings->JOY_FIRE3_AUTO=key_settings->JOY_FIRE3_AUTO?0:1; break;
				case 3: key_settings->JOY_FIRE1=button_next((key_settings->JOY_FIRE1),(ExKey&GP2X_R)); break;
				case 4: key_settings->JOY_FIRE2=button_next((key_settings->JOY_FIRE2),(ExKey&GP2X_R)); break;
				case 5: key_settings->JOY_FIRE3=button_next((key_settings->JOY_FIRE3),(ExKey&GP2X_R)); break;
				case 6: key_settings->JOY_FIRE4=button_next((key_settings->JOY_FIRE4),(ExKey&GP2X_R)); break;
				case 7: key_settings->JOY_FIRE5=button_next((key_settings->JOY_FIRE5),(ExKey&GP2X_R)); break;
				case 8: key_settings->JOY_FIRE6=button_next((key_settings->JOY_FIRE6),(ExKey&GP2X_R)); break;
				case 9: key_settings->JOY_FIRE7=button_next((key_settings->JOY_FIRE7),(ExKey&GP2X_R)); break;
				case 10: key_settings->JOY_FIRE8=button_next((key_settings->JOY_FIRE8),(ExKey&GP2X_R)); break;
				case 11: key_settings->JOY_FIRE9=button_next((key_settings->JOY_FIRE9),(ExKey&GP2X_R)); break;
				case 12: key_settings->JOY_FIRE10=button_next((key_settings->JOY_FIRE10),(ExKey&GP2X_R)); break;
				case 13:
					/* X Sensitivity */
#ifdef GP2X
					if (ExKey & GP2X_R) {
#else
					if (ExKey & GP2X_RIGHT) {
#endif
						if (x_sensitivity!=-1) {
							x_sensitivity+=5;
							if (x_sensitivity>255) x_sensitivity=-1;
						} else
							x_sensitivity=0;
					} else {
						if (x_sensitivity!=-1) {
							x_sensitivity-=5;
							if (x_sensitivity<0) x_sensitivity=-1;
						} else
							x_sensitivity=255;
					}
					break;
				case 14:
					/* X Reversed */
					x_reversed=!x_reversed;
					break;
				case 15:
					/* Y Sensitivity */
#ifdef GP2X
					if (ExKey & GP2X_R) {
#else
					if (ExKey & GP2X_RIGHT) {
#endif
						if (y_sensitivity!=-1) {
							y_sensitivity+=5;
							if (y_sensitivity>255) y_sensitivity=-1;
						} else
							y_sensitivity=0;
					} else {
						if (y_sensitivity!=-1) {
							y_sensitivity-=5;
							if (y_sensitivity<0) y_sensitivity=-1;
						} else
							y_sensitivity=255;
					}
					break;
				case 16:
					/* Y Reversed */
					y_reversed=!y_reversed;
					break;
				case 17:
					/* Default Values */
					key_settings->JOY_FIRE1=GP2X_A;
					key_settings->JOY_FIRE2=GP2X_X;
					key_settings->JOY_FIRE3=GP2X_B;
					key_settings->JOY_FIRE4=GP2X_Y;
					key_settings->JOY_FIRE5=GP2X_L;
					key_settings->JOY_FIRE6=GP2X_R;
					key_settings->JOY_FIRE7=GP2X_VOL_UP;
					key_settings->JOY_FIRE8=GP2X_VOL_DOWN;
					key_settings->JOY_FIRE9=GP2X_PUSH;
					key_settings->JOY_FIRE10=GP2X_START;
					key_settings->JOY_FIRE1_AUTO=0;
					key_settings->JOY_FIRE2_AUTO=0;
					key_settings->JOY_FIRE3_AUTO=0;
					x_sensitivity=-1;
					y_sensitivity=-1;
					x_reversed=0;
					y_reversed=0;
					break;
			}
		}
		
		if ((ExKey & GP2X_A) || (ExKey & GP2X_PUSH) || (ExKey & GP2X_START)) {
			return;
		}
		else if ((ExKey & GP2X_B) || (ExKey & GP2X_SELECT)){
			return;
		}
	}
}

#define SAVEDATASTRUCTURE "gp2x_freq=%d;gp3x_frameskip=%d;gp2x_frameskip_auto=%d;gp2x_clock_cpu=%d;gp2x_sound_enable=%d;gp2x_clock_sound=%d;key_setting=%ld,%ld,%ld,%ld,%ld,%ld,%ld,%ld,%ld,%ld,%d,%d,%d,%d;gp2x_double_buffer=%d;gp2x_vsync=%d;gp2x_autofire=%d,%d,%d;\0"
#define SAVEDATAFILEDEF	"%scfg/mame.cfg\0"
#define SAVEDATAFILECFG "%scfg/%s.cfg\0"
static int show_options(char *game)
{
	unsigned long ExKey=0;
	int selected_option=0;
	int x_Pos = 41;
	int y_Pos = 58;
	int options_count = 8;
	char text[256];
	FILE *f;

	/* Load Configuration Files */
	gp2x_save_config = 0;
	sprintf(text,SAVEDATAFILEDEF, gp2x_path_mame);
	f=fopen(text,"r");
	if (f) {
		fscanf(f,SAVEDATASTRUCTURE,
		&gp2x_freq,&gp2x_frameskip,&gp2x_frameskip_auto,&gp2x_clock_cpu,&gp2x_sound_enable,&gp2x_clock_sound,
		&(key_settings->JOY_FIRE1),&(key_settings->JOY_FIRE2),&(key_settings->JOY_FIRE3),&(key_settings->JOY_FIRE4),
		&(key_settings->JOY_FIRE5),&(key_settings->JOY_FIRE6),&(key_settings->JOY_FIRE7),&(key_settings->JOY_FIRE8),
		&(key_settings->JOY_FIRE9),&(key_settings->JOY_FIRE10),&x_sensitivity,&x_reversed,&y_sensitivity,&y_reversed,
		&gp2x_double_buffer,&gp2x_vsync,&(key_settings->JOY_FIRE1_AUTO),&(key_settings->JOY_FIRE2_AUTO),&(key_settings->JOY_FIRE3_AUTO));
		fclose(f);
	}
	sprintf(text,SAVEDATAFILECFG, gp2x_path_mame, game);
	f=fopen(text,"r");
	if (f) {
		fscanf(f,SAVEDATASTRUCTURE,
		&gp2x_freq,&gp2x_frameskip,&gp2x_frameskip_auto,&gp2x_clock_cpu,&gp2x_sound_enable,&gp2x_clock_sound,
		&(key_settings->JOY_FIRE1),&(key_settings->JOY_FIRE2),&(key_settings->JOY_FIRE3),&(key_settings->JOY_FIRE4),
		&(key_settings->JOY_FIRE5),&(key_settings->JOY_FIRE6),&(key_settings->JOY_FIRE7),&(key_settings->JOY_FIRE8),
		&(key_settings->JOY_FIRE9),&(key_settings->JOY_FIRE10),&x_sensitivity,&x_reversed,&y_sensitivity,&y_reversed,
		&gp2x_double_buffer,&gp2x_vsync,&(key_settings->JOY_FIRE1_AUTO),&(key_settings->JOY_FIRE2_AUTO),&(key_settings->JOY_FIRE3_AUTO));
		fclose(f);
	}


	while(1)
	{
		/* Draw background image */
		load_bmp_8bpp(gp2x_screen8,gp2xmenu_bmp);

		/* Draw the options */
		gp2x_gamelist_text_out(x_Pos,y_Pos,"Selected Game:\0");
		fast_memcpy (text,game_list_description(last_game_selected),33);
		text[32]='\0';
		gp2x_gamelist_text_out(x_Pos,y_Pos+10,text);
		/*gp2x_gamelist_text_out(x_Pos,y_Pos+10,game_list_description(last_game_selected));*/

#ifdef GP2X
		/* GP2X Clock*/
		gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+30, "GP2X Clock    %d MHz", gp2x_freq);
		
		/* Frame-Skip */
		if(gp2x_frameskip_auto && gp2x_frameskip!=0) {
			gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+40,"Frame-Skip    %s %d %s","<=",gp2x_frameskip, "(Auto-skip)");
		}
		else{
			gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+40,"Frame-Skip    %s %d %s","=",gp2x_frameskip,"");
		}
#else
		switch (gp2x_rotate)
		{
			case 0: gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+30,"Video         %s","Fixed"); break;
			case 1: gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+30,"Video         %s","Fixed DIV2"); break;
			case 2: gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+30,"Video         %s","SW Scaled"); break;
			default: gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+30,"Video         %s","HW Scaled"); break;
		}
		if (gp2x_frameskip_auto)
		{
			gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+40,"Frame-Skip    Auto");
			gp2x_frameskip=-1;
		}
		else
			gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+40,"Frame-Skip    = %d",gp2x_frameskip);
#endif

		/* Video Clock */
		gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+50,"Video Clock   %d%%",gp2x_clock_cpu);

		/* Video Sync */
#ifdef GP2X
		if (gp2x_double_buffer && gp2x_vsync)
			gp2x_gamelist_text_out(x_Pos,y_Pos+60,"Video Sync    VSync+DblBuf");
		else if (gp2x_double_buffer && !gp2x_vsync)
			gp2x_gamelist_text_out(x_Pos,y_Pos+60,"Video Sync    DblBuf");
		else if (!gp2x_double_buffer && gp2x_vsync)
			gp2x_gamelist_text_out(x_Pos,y_Pos+60,"Video Sync    VSync");
		else
			gp2x_gamelist_text_out(x_Pos,y_Pos+60,"Video Sync    None");
#else
		if (gp2x_vsync)
			gp2x_gamelist_text_out(x_Pos,y_Pos+60,"Video Sync    On");
		else
			gp2x_gamelist_text_out(x_Pos,y_Pos+60,"Video Sync    Off");

#endif
		/* Sound */
		switch(gp2x_sound_enable)
		{
			case 0: gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+70,"Sound         %s","Sound OFF"); break;
			case 1: gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+70,"Sound         %s","Sound ON"); break;
			case 2: gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+70,"Sound         %s","Emulated but OFF"); break;
			case 3: gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+70,"Sound         %s","Accurate and ON"); break;
		}

		/* Audio Clock */
		gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+80,"Audio Clock   %d%%",gp2x_clock_sound);

		/* Controller Configuration */
		gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+90,"Controller Configuration");

		/* Save Configuration */
		switch(gp2x_save_config) {
			case 0: gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+100,"No Save Configuration"); break;
			case 1: gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+100,"Save Configuration"); break;
			case 2: gp2x_gamelist_text_out_fmt(x_Pos,y_Pos+100,"Save as Default"); break;
		}
		
		gp2x_gamelist_text_out(x_Pos,y_Pos+120,"Press A to confirm, B return\0");

		/* Show currently selected item */
		gp2x_gamelist_text_out(x_Pos-16,y_Pos+(selected_option*10)+30," >");

		gp2x_video_flip();
		while(gp2x_joystick_read()&0x8c0ff55) { gp2x_timer_delay(150); }
		while(!(ExKey=gp2x_joystick_read()&0x8c0ff55)) { }
		if(ExKey & GP2X_DOWN){
			selected_option++;
			selected_option = selected_option % options_count;
		}
		else if(ExKey & GP2X_UP){
			selected_option--;
			if(selected_option<0)
				selected_option = options_count - 1;
		}
#ifdef GP2X
		else if(ExKey & GP2X_R || ExKey & GP2X_L){
#else
		else if(ExKey & GP2X_RIGHT || ExKey & GP2X_LEFT){
#endif
			switch(selected_option) {
			case 0:
#ifdef GP2X
				/* GP2X Clock */
				if(ExKey & GP2X_R){
					switch (gp2x_freq) {
						case 133: gp2x_freq=150;break;
						case 150: gp2x_freq=166;break;
						case 166: gp2x_freq=180;break;
						case 180: gp2x_freq=200;break;
						case 200: gp2x_freq=225;break;
						case 225: gp2x_freq=233;break;
						case 233: gp2x_freq=245;break;
						case 245: gp2x_freq=250;break;
						case 250: gp2x_freq=255;break;
						case 255: gp2x_freq=260;break;
						case 260: gp2x_freq=265;break;
						case 265: gp2x_freq=266;break;
						case 266: gp2x_freq=270;break;
						case 270: gp2x_freq=275;break;
						case 275: gp2x_freq=280;break;
						case 280: gp2x_freq=285;break;
						case 285: gp2x_freq=290;break;
						case 290: gp2x_freq=295;break;
						case 295: gp2x_freq=300;break;
						case 300: gp2x_freq=133;break;
					}
				} else {
					switch (gp2x_freq) {
						case 133: gp2x_freq=300;break;
						case 150: gp2x_freq=133;break;
						case 166: gp2x_freq=150;break;
						case 180: gp2x_freq=166;break;
						case 200: gp2x_freq=180;break;
						case 225: gp2x_freq=200;break;
						case 233: gp2x_freq=225;break;
						case 245: gp2x_freq=233;break;
						case 250: gp2x_freq=245;break;
						case 255: gp2x_freq=250;break;
						case 260: gp2x_freq=255;break;
						case 265: gp2x_freq=260;break;
						case 266: gp2x_freq=265;break;
						case 270: gp2x_freq=266;break;
						case 275: gp2x_freq=270;break;
						case 280: gp2x_freq=275;break;
						case 285: gp2x_freq=280;break;
						case 290: gp2x_freq=285;break;
						case 295: gp2x_freq=290;break;
						case 300: gp2x_freq=295;break;
					}
				}
#else
				if (ExKey & GP2X_RIGHT)
					gp2x_rotate++;
				else
				if (ExKey & GP2X_LEFT)
					gp2x_rotate--;
				if (gp2x_rotate<0)
					gp2x_rotate=3;
				else if (gp2x_rotate>3)
					gp2x_rotate=0;

#endif
				break;
			case 1:
				/* "Frame-Skip" */
#ifdef GP2X
				if(ExKey & GP2X_R){
#else
				if(ExKey & GP2X_RIGHT){
#endif
					gp2x_frameskip ++;
					if (!gp2x_frameskip)
						gp2x_frameskip_auto=0;
					else
					if (gp2x_frameskip > 5) {
#ifdef GP2X
						gp2x_frameskip = 0;
						gp2x_frameskip_auto=!gp2x_frameskip_auto; 
#else
						gp2x_frameskip = -1;
						gp2x_frameskip_auto = 1;
#endif
					}
				}
				else{
					gp2x_frameskip--;
#ifdef GP2X
					if (gp2x_frameskip < 0){
						gp2x_frameskip = 5;
						gp2x_frameskip_auto=!gp2x_frameskip_auto; 
					}
#else
					if (gp2x_frameskip==-1)
						gp2x_frameskip_auto=1;
					else if (gp2x_frameskip<-1)
					{
						gp2x_frameskip = 5;
						gp2x_frameskip_auto = 0;
					}
#endif
				}
				break;
			case 2:
				/* "Video Clock" */
#ifdef GP2X
				if(ExKey & GP2X_R){
#else
				if(ExKey & GP2X_RIGHT){
#endif
					gp2x_clock_cpu += 10; /* Add 10% */
					if (gp2x_clock_cpu > 200) /* 200% is the max */
						gp2x_clock_cpu = 200;
				}
				else{
					gp2x_clock_cpu -= 10; /* Subtract 10% */
					if (gp2x_clock_cpu < 10) /* 10% is the min */
						gp2x_clock_cpu = 10;
				}
				break;
			case 3:
				/* Video Sync */
#ifdef GP2X
				if (gp2x_double_buffer && gp2x_vsync)
				{ gp2x_double_buffer=0; gp2x_vsync=0; }	
				else if (gp2x_double_buffer && !gp2x_vsync)
				{ gp2x_double_buffer=0; gp2x_vsync=1; }	
				else if (!gp2x_double_buffer && gp2x_vsync)
				{ gp2x_double_buffer=1; gp2x_vsync=1; }	
				else
				{ gp2x_double_buffer=1; gp2x_vsync=0; }	
#else
				gp2x_vsync=(gp2x_vsync+1)&1;
#endif
				break;

			case 4:
#ifndef NOSOUND
				/* "Sound" */
				gp2x_sound_enable--;
				if (gp2x_sound_enable<0)
					gp2x_sound_enable=3;
#endif
				break;
			case 5:
				/* "Audio Clock" */
#ifdef GP2X
				if(ExKey & GP2X_R){
#else
				if(ExKey & GP2X_RIGHT){
#endif
					gp2x_clock_sound += 10; /* Add 10% */
					if (gp2x_clock_sound > 200) /* 200% is the max */
						gp2x_clock_sound = 200;
				}
				else{
					gp2x_clock_sound -= 10; /* Subtract 10% */
					if (gp2x_clock_sound < 10) /* 10% is the min */
						gp2x_clock_sound = 10;
				}
				break;
			case 6:
				/* Controller Configuration */
				controller_config();
				break;
			case 7:
				/* Save Configuration */
#ifdef GP2X
				if(ExKey & GP2X_R){
#else
				if(ExKey & GP2X_RIGHT){
#endif
					gp2x_save_config += 1;
					if (gp2x_save_config > 2)
						gp2x_save_config = 0;
				}
				else{
					gp2x_save_config -= 1;
					if (gp2x_save_config < 0)
						gp2x_save_config = 2;
				}
				break;
			}
		}
#ifndef GP2X
		if ((ExKey & GP2X_A) || (ExKey & GP2X_START)) {
#else
		if ((ExKey & GP2X_A) || (ExKey & GP2X_PUSH) || (ExKey & GP2X_START)) {
#endif

			/* Save Configuration Files */
			if (gp2x_save_config>1) {
				sprintf(text,SAVEDATAFILEDEF, gp2x_path_mame);
				f=fopen(text,"w");
				if (f) {
					fprintf(f,SAVEDATASTRUCTURE,
					gp2x_freq,gp2x_frameskip,gp2x_frameskip_auto,gp2x_clock_cpu,gp2x_sound_enable,gp2x_clock_sound,
					(key_settings->JOY_FIRE1),(key_settings->JOY_FIRE2),(key_settings->JOY_FIRE3),(key_settings->JOY_FIRE4),
					(key_settings->JOY_FIRE5),(key_settings->JOY_FIRE6),(key_settings->JOY_FIRE7),(key_settings->JOY_FIRE8),
					(key_settings->JOY_FIRE9),(key_settings->JOY_FIRE10),x_sensitivity,x_reversed,y_sensitivity,y_reversed,
					gp2x_double_buffer,gp2x_vsync,(key_settings->JOY_FIRE1_AUTO),(key_settings->JOY_FIRE2_AUTO),(key_settings->JOY_FIRE3_AUTO));
					fclose(f);
#ifdef GP2X
					sync();
#endif
				}
			}
			if (gp2x_save_config>0) {
				sprintf(text,SAVEDATAFILECFG, gp2x_path_mame, game);
				f=fopen(text,"w");
				if (f) {
					fprintf(f,SAVEDATASTRUCTURE,
					gp2x_freq,gp2x_frameskip,gp2x_frameskip_auto,gp2x_clock_cpu,gp2x_sound_enable,gp2x_clock_sound,
					(key_settings->JOY_FIRE1),(key_settings->JOY_FIRE2),(key_settings->JOY_FIRE3),(key_settings->JOY_FIRE4),
					(key_settings->JOY_FIRE5),(key_settings->JOY_FIRE6),(key_settings->JOY_FIRE7),(key_settings->JOY_FIRE8),
					(key_settings->JOY_FIRE9),(key_settings->JOY_FIRE10),x_sensitivity,x_reversed,y_sensitivity,y_reversed,
					gp2x_double_buffer,gp2x_vsync,(key_settings->JOY_FIRE1_AUTO),(key_settings->JOY_FIRE2_AUTO),(key_settings->JOY_FIRE3_AUTO));
					fclose(f);
#ifdef GP2X
					sync();
#endif
				}
			}

			/* Selected game will be run */
			return 1;
		}
#ifndef GP2X
		else if ((ExKey & GP2X_X) || (ExKey & GP2X_PUSH) || (ExKey & GP2X_SELECT)){
#else
		else if ((ExKey & GP2X_B) || (ExKey & GP2X_SELECT)){
#endif
			/* Return To Menu */
			return 0;
		}
	}
}

void select_game(char *game) {

	unsigned long ExKey;
	int c;

	/* No Selected game */
	strcpy(game,"builtinn");

	/* Clean screen */
	gp2x_video_flip();

	/* Wait until no key pressed */
	while(gp2x_joystick_read()&0x8c0ff55) { }

	/* Available games? */
	if(game_num_avail==0) {
		gp2x_mame_palette();
		gp2x_text_out( 35, 110, "ERROR: NO AVAILABLE GAMES FOUND" );
		gp2x_video_flip();
		while(1) { if (gp2x_joystick_read()&GP2X_A) exit(0);}
	}

	SetGP2XClock(200);

	/* Wait until user selects a game */
	while(1) {
		game_list_view(&last_game_selected);
		gp2x_video_flip();

#ifdef GP2X
		if( (gp2x_joystick_read()&0x8c0ff55)) 
			gp2x_timer_delay(150); 
		while(!(ExKey=gp2x_joystick_read()&0x8c0ff55)) { if ((ExKey & GP2X_L) && (ExKey & GP2X_R)) exit(0); }
#else
		if( (gp2x_joystick_read()&0x8c0ff55)) 
			gp2x_timer_delay(100); 
		while(!(ExKey=gp2x_joystick_read()&0x8c0ff55))
			gp2x_timer_delay(100); 
#endif

		if (ExKey & GP2X_UP) last_game_selected--;
		if (ExKey & GP2X_DOWN) last_game_selected++;
		if (ExKey & GP2X_L) last_game_selected-=21;
		if (ExKey & GP2X_R) last_game_selected+=21;
		if ((ExKey & GP2X_L) && (ExKey & GP2X_R)) exit(0);

		/* If Button A is pressed, or a rom name was passed to this application */
#ifndef GP2X
		{
#ifdef DREAMCAST
			static int parasalir=0;
			if (ExKey & GP2X_PUSH)
				parasalir++;
			else
				parasalir=0;
			if (parasalir>8)
				gp2x_deinit();
#else
			if (ExKey & GP2X_PUSH)
				gp2x_deinit();
#endif
		}
		if ((ExKey & GP2X_A) || (ExKey & GP2X_START))
#else
		if ((ExKey & GP2X_A) || (ExKey & GP2X_PUSH) || (ExKey & GP2X_START))
#endif
		{
			/* Select the game */
			game_list_select(last_game_selected, game);

			/* Emulation Options */
			if(show_options(game))
			{
				/* break out of the while(1) loop */
				break;
			}
		}
	}

	SetGP2XClock(gp2x_freq);
}

